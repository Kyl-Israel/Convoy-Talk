package com.convoytalk.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.sign

/**
 * Draws the corner brackets (and optional + sign) on the scanner and QR cards.
 * maskColor paints the area outside the rounded corners so the camera
 * preview looks like a rounded card.
 */
class CornerFrameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var maskColor: Int = Color.TRANSPARENT
    var cornerRadiusDp: Float = 28f
    var bracketColor: Int = Color.WHITE
    var strokeDp: Float = 3f
    var bracketInset: Float = 0.17f
    var bracketLength: Float = 0.16f
    var bracketRoundDp: Float = 0f
    var drawPlus: Boolean = true
    var drawBrackets: Boolean = true

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.MITER
    }
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (Color.alpha(maskColor) != 0) {
            path.reset()
            path.fillType = Path.FillType.EVEN_ODD
            path.addRect(0f, 0f, w, h, Path.Direction.CW)
            rect.set(0f, 0f, w, h)
            path.addRoundRect(rect, cornerRadiusDp * d, cornerRadiusDp * d, Path.Direction.CW)
            fill.color = maskColor
            canvas.drawPath(path, fill)
        }

        if (!drawBrackets && !drawPlus) return

        stroke.color = bracketColor
        stroke.strokeWidth = strokeDp * d
        stroke.strokeCap = if (bracketRoundDp > 0f) Paint.Cap.ROUND else Paint.Cap.SQUARE
        val left = w * bracketInset
        val top = h * bracketInset
        val right = w - left
        val bottom = h - top
        val len = minOf(w, h) * bracketLength
        val round = bracketRoundDp * d
        if (drawBrackets) {
            drawCorner(canvas, left, top + len, left, top, left + len, top, round)
            drawCorner(canvas, right - len, top, right, top, right, top + len, round)
            drawCorner(canvas, right, bottom - len, right, bottom, right - len, bottom, round)
            drawCorner(canvas, left + len, bottom, left, bottom, left, bottom - len, round)
        }

        if (drawPlus) {
            val cx = w / 2f
            val cy = h / 2f
            val p = minOf(w, h) * 0.07f
            canvas.drawLine(cx - p, cy, cx + p, cy, stroke)
            canvas.drawLine(cx, cy - p, cx, cy + p, stroke)
        }
    }

    private fun drawCorner(
        canvas: Canvas,
        x1: Float, y1: Float,
        cx: Float, cy: Float,
        x3: Float, y3: Float,
        round: Float
    ) {
        path.reset()
        path.fillType = Path.FillType.WINDING
        path.moveTo(x1, y1)
        if (round > 0f) {
            val ax = cx + sign(x1 - cx) * round
            val ay = cy + sign(y1 - cy) * round
            val bx = cx + sign(x3 - cx) * round
            val by = cy + sign(y3 - cy) * round
            path.lineTo(ax, ay)
            path.quadTo(cx, cy, bx, by)
        } else {
            path.lineTo(cx, cy)
        }
        path.lineTo(x3, y3)
        canvas.drawPath(path, stroke)
    }
}
