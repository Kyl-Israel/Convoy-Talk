package com.convoytalk.app

// Packet format: MAGIC byte, TYPE byte, then payload. Sent over UDP.
object Protocol {
    const val PORT = 50005
    const val SAMPLE_RATE = 16000
    const val FRAME_SAMPLES = 320            // 20 ms at 16 kHz
    const val FRAME_BYTES = FRAME_SAMPLES * 2

    const val MAGIC: Byte = 0x43
    const val TYPE_HELLO: Byte = 1    // client -> host, payload: name
    const val TYPE_WELCOME: Byte = 2  // host -> client
    const val TYPE_AUDIO: Byte = 3    // client -> host, payload: PCM frame
    const val TYPE_MIX: Byte = 4      // host -> client, payload: mixed PCM frame
    const val TYPE_BYE: Byte = 5      // client -> host
    const val TYPE_MEMBERS: Byte = 6  // host -> client, payload: names separated by \n

    fun shortsToBytes(src: ShortArray, dst: ByteArray, offset: Int) {
        var j = offset
        for (s in src) {
            val v = s.toInt()
            dst[j] = (v and 0xFF).toByte()
            dst[j + 1] = ((v shr 8) and 0xFF).toByte()
            j += 2
        }
    }

    fun bytesToShorts(src: ByteArray, offset: Int, count: Int): ShortArray {
        val out = ShortArray(count)
        var j = offset
        for (i in 0 until count) {
            val lo = src[j].toInt() and 0xFF
            val hi = src[j + 1].toInt()
            out[i] = ((hi shl 8) or lo).toShort()
            j += 2
        }
        return out
    }
}
