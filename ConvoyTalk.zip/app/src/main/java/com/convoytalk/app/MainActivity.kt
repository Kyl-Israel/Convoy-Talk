package com.convoytalk.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.ResultPoint
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.BarcodeView
import com.journeyapps.barcodescanner.DefaultDecoderFactory
import com.journeyapps.barcodescanner.camera.CenterCropStrategy

class MainActivity : AppCompatActivity() {

    private lateinit var joinScreen: View
    private lateinit var connectedScreen: View
    private lateinit var hostScreen: View
    private lateinit var barcodeView: BarcodeView
    private lateinit var scannerOverlay: CornerFrameView
    private lateinit var cameraHint: TextView
    private lateinit var connectedPill: TextView
    private lateinit var qrImage: ImageView
    private lateinit var qrLoading: ProgressBar
    private lateinit var hostHint: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var noDevices: TextView
    private lateinit var banner: TextView

    private val ui = Handler(Looper.getMainLooper())
    private var currentScreen: View? = null
    private var lastMode: AppState.Mode? = null
    private var shownQr: String? = null
    private var shownMembers: List<String>? = null
    private var cameraRunning = false
    private var resumed = false
    private var askedWifi = false
    private var lastScanAt = 0L
    private var pendingHotspotJoin = false
    private var hotspotFlow = false
    private var pendingAction: (() -> Unit)? = null
    private lateinit var safetyScreen: View
    private lateinit var safetyScroll: ScrollView
    private lateinit var safetyOkButton: TextView
    private lateinit var safetyHint: TextView
    private var safetyVisible = false
    private var safetyFirstTime = false
    private var safetyRead = false
    private val bannerQueue = ArrayDeque<String>()
    private var bannerShowing = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            updateCamera()
            val action = pendingAction
            pendingAction = null
            if (action != null) {
                if (hasPermission(Manifest.permission.RECORD_AUDIO)) {
                    action()
                } else {
                    showBanner("Allow the microphone so your friends can hear you")
                }
            } else {
                askWifiOnce()
            }
        }

    /**
     * Back button:
     * - safety rules opened from the info icon: close them
     * - scan screen (or first-time rules): exit the app completely
     * - hosting / connected: go to the background and keep the call running
     */
    private val backHandler = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            when {
                safetyVisible && !safetyFirstTime -> hideSafety()
                safetyVisible || AppState.mode == AppState.Mode.IDLE -> exitApp()
                else -> moveTaskToBack(true)
            }
        }
    }

    private fun exitApp() {
        if (AppState.mode != AppState.Mode.IDLE) stopIntercom()
        finishAndRemoveTask()
    }

    private val refresher = object : Runnable {
        override fun run() {
            refreshUi()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Phone volume buttons control the voice (call) volume in this app.
        volumeControlStream = AudioManager.STREAM_VOICE_CALL

        joinScreen = findViewById(R.id.joinScreen)
        connectedScreen = findViewById(R.id.connectedScreen)
        hostScreen = findViewById(R.id.hostScreen)
        barcodeView = findViewById(R.id.barcodeView)
        scannerOverlay = findViewById(R.id.scannerOverlay)
        cameraHint = findViewById(R.id.cameraHint)
        connectedPill = findViewById(R.id.connectedPill)
        qrImage = findViewById(R.id.qrImage)
        qrLoading = findViewById(R.id.qrLoading)
        hostHint = findViewById(R.id.hostHint)
        deviceList = findViewById(R.id.deviceList)
        noDevices = findViewById(R.id.noDevices)
        banner = findViewById(R.id.banner)

        val green = ContextCompat.getColor(this, R.color.ct_green)

        // Scanner card: plain rounded camera view, no guide marks.
        scannerOverlay.maskColor = green
        scannerOverlay.cornerRadiusDp = 28f
        scannerOverlay.drawBrackets = false
        scannerOverlay.drawPlus = false

        // Host QR card: thick black rounded brackets.
        val qrOverlay = findViewById<CornerFrameView>(R.id.qrOverlay)
        qrOverlay.maskColor = green
        qrOverlay.cornerRadiusDp = 28f
        qrOverlay.bracketColor = Color.BLACK
        qrOverlay.strokeDp = 7f
        qrOverlay.bracketInset = 0.05f
        qrOverlay.bracketLength = 0.22f
        qrOverlay.bracketRoundDp = 12f
        qrOverlay.drawPlus = false

        barcodeView.setDecoderFactory(DefaultDecoderFactory(listOf(BarcodeFormat.QR_CODE)))
        barcodeView.setPreviewScalingStrategy(CenterCropStrategy())
        barcodeView.decodeContinuous(object : BarcodeCallback {
            override fun barcodeResult(result: BarcodeResult) {
                onScanned(result.text)
            }

            override fun possibleResultPoints(resultPoints: List<ResultPoint>) {}
        })

        findViewById<View>(R.id.generateButton).setOnClickListener { onGenerate() }
        findViewById<View>(R.id.disconnectButton).setOnClickListener { stopIntercom() }
        findViewById<View>(R.id.endButton).setOnClickListener { stopIntercom() }
        findViewById<View>(R.id.scannerCard).setOnClickListener {
            if (!hasPermission(Manifest.permission.CAMERA)) {
                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            }
        }

        showScreen(screenFor(AppState.mode), false)
        lastMode = AppState.mode

        safetyScreen = findViewById(R.id.safetyScreen)
        safetyScroll = findViewById(R.id.safetyScroll)
        safetyOkButton = findViewById(R.id.safetyOkButton)
        safetyHint = findViewById(R.id.safetyHint)
        findViewById<TextView>(R.id.safetyText).text = SafetyRules.text()
        safetyScroll.setOnScrollChangeListener { _, _, _, _, _ -> checkSafetyRead() }
        safetyOkButton.setOnClickListener { onSafetyAccepted() }
        findViewById<View>(R.id.infoButton).setOnClickListener { showSafety(false) }
        onBackPressedDispatcher.addCallback(this, backHandler)

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (prefs.getBoolean("safetyAccepted", false)) {
            startupChecks()
        } else {
            showSafety(true)
        }
    }

    /** Permissions and the Wi-Fi prompt, after the safety rules are accepted. */
    private fun startupChecks() {
        val missing = neededPermissions().filter { !hasPermission(it) }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            askWifiOnce()
        }
    }

    // ---------- Safety rules ----------

    private fun showSafety(firstTime: Boolean) {
        safetyFirstTime = firstTime
        safetyVisible = true
        // First time: the button unlocks only after scrolling to the last rule.
        safetyRead = !firstTime
        updateSafetyButton()
        safetyScroll.scrollTo(0, 0)
        safetyScreen.animate().cancel()
        safetyScreen.alpha = 0f
        safetyScreen.visibility = View.VISIBLE
        safetyScreen.animate().alpha(1f).setDuration(220).start()
        updateCamera()
        safetyScroll.post { checkSafetyRead() }
    }

    private fun hideSafety() {
        safetyVisible = false
        safetyScreen.animate().cancel()
        safetyScreen.animate().alpha(0f).setDuration(200).withEndAction {
            if (!safetyVisible) safetyScreen.visibility = View.GONE
        }.start()
        updateCamera()
    }

    private fun checkSafetyRead() {
        if (!safetyRead && !safetyScroll.canScrollVertically(1)) {
            safetyRead = true
            updateSafetyButton()
        }
    }

    private fun updateSafetyButton() {
        safetyOkButton.isEnabled = safetyRead
        safetyOkButton.alpha = if (safetyRead) 1f else 0.45f
        safetyHint.visibility = if (safetyRead) View.INVISIBLE else View.VISIBLE
    }

    private fun onSafetyAccepted() {
        if (!safetyRead) return
        val first = safetyFirstTime
        getSharedPreferences("settings", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("safetyAccepted", true)
            .apply()
        hideSafety()
        if (first) startupChecks()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        refreshUi()
        updateCamera()
        if (pendingHotspotJoin) {
            // Back from the Wi-Fi sheet.
            pendingHotspotJoin = false
            joinHotspotWhenReady(0)
        }
        ui.removeCallbacks(refresher)
        ui.postDelayed(refresher, 250)
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        ui.removeCallbacks(refresher)
        updateCamera()
    }

    // ---------- Screens ----------

    private fun screenFor(mode: AppState.Mode): View = when (mode) {
        AppState.Mode.IDLE -> joinScreen
        AppState.Mode.HOST_STARTING, AppState.Mode.HOSTING -> hostScreen
        else -> connectedScreen
    }

    private fun showScreen(target: View, animate: Boolean) {
        val old = currentScreen
        currentScreen = target
        for (s in listOf(joinScreen, connectedScreen, hostScreen)) {
            if (s === target) continue
            s.animate().cancel()
            if (animate && s === old) {
                s.animate().alpha(0f).setDuration(180).withEndAction {
                    if (currentScreen !== s) s.visibility = View.GONE
                }.start()
            } else {
                s.visibility = View.GONE
            }
        }
        target.animate().cancel()
        if (animate) {
            target.alpha = 0f
            target.visibility = View.VISIBLE
            target.animate().alpha(1f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        } else {
            target.alpha = 1f
            target.visibility = View.VISIBLE
        }
    }

    private fun refreshUi() {
        val mode = AppState.mode
        if (mode != lastMode) {
            lastMode = mode
            val target = screenFor(mode)
            if (target !== currentScreen) showScreen(target, true)
            updateCamera()
            if (mode == AppState.Mode.CONNECTED || mode == AppState.Mode.HOSTING) askBatteryOnce()
        }

        connectedPill.text = when (mode) {
            AppState.Mode.JOINING -> "CONNECTING…"
            AppState.Mode.RECONNECTING -> "RECONNECTING…"
            else -> "CONNECTED"
        }

        // Host QR
        val qr = AppState.qrText
        if (qr != shownQr) {
            shownQr = qr
            if (qr == null) {
                qrImage.setImageDrawable(null)
                qrLoading.visibility = View.VISIBLE
            } else {
                val bmp: Bitmap? = try {
                    BarcodeEncoder().encodeBitmap(qr, BarcodeFormat.QR_CODE, 600, 600)
                } catch (e: Exception) {
                    null
                }
                qrImage.alpha = 0f
                qrImage.setImageBitmap(bmp)
                qrImage.animate().alpha(1f).setDuration(250).start()
                qrLoading.visibility = View.GONE
            }
        }
        val hint = AppState.hostHint
        hostHint.text = hint ?: ""
        hostHint.visibility = if (hint == null) View.GONE else View.VISIBLE

        // Host device list
        val members = AppState.members
        if (members != shownMembers) {
            shownMembers = members
            renderMembers(members)
        }

        // Pop-up banners
        while (true) {
            val e = AppState.events.poll() ?: break
            bannerQueue.addLast(e)
        }
        if (!bannerShowing) showNextBanner()

        if (AppState.hotspotHelp) {
            AppState.hotspotHelp = false
            showHotspotDialog()
        }
    }

    private fun renderMembers(names: List<String>) {
        val remaining = names.toMutableList()
        for (i in deviceList.childCount - 1 downTo 0) {
            val v = deviceList.getChildAt(i) as TextView
            if (!remaining.remove(v.text.toString())) deviceList.removeViewAt(i)
        }
        for (n in remaining) deviceList.addView(makeDeviceRow(n))
        noDevices.visibility = if (names.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun makeDeviceRow(name: String): TextView {
        val tv = TextView(this)
        tv.text = name
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.dot_orange, 0, 0, 0)
        tv.compoundDrawablePadding = dp(10)
        tv.setPadding(0, dp(4), 0, dp(4))
        return tv
    }

    // ---------- Banners ----------

    private fun showBanner(message: String) {
        bannerQueue.addLast(message)
        if (!bannerShowing) showNextBanner()
    }

    private fun showNextBanner() {
        val message = bannerQueue.removeFirstOrNull() ?: return
        bannerShowing = true
        val hidden = -dp(140).toFloat()
        banner.text = message
        banner.animate().cancel()
        banner.translationY = hidden
        banner.alpha = 0f
        banner.visibility = View.VISIBLE
        banner.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(280)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                banner.postDelayed({
                    banner.animate()
                        .translationY(hidden)
                        .alpha(0f)
                        .setDuration(220)
                        .setInterpolator(AccelerateInterpolator())
                        .withEndAction {
                            banner.visibility = View.INVISIBLE
                            bannerShowing = false
                            showNextBanner()
                        }
                        .start()
                }, 1800)
            }
            .start()
    }

    // ---------- Camera ----------

    private fun updateCamera() {
        val hasCamera = hasPermission(Manifest.permission.CAMERA)
        val want = resumed && hasCamera && !safetyVisible && AppState.mode == AppState.Mode.IDLE
        if (want && !cameraRunning) {
            barcodeView.visibility = View.VISIBLE
            barcodeView.resume()
            cameraRunning = true
        } else if (!want && cameraRunning) {
            barcodeView.pause()
            cameraRunning = false
        }
        if (!hasCamera) {
            barcodeView.visibility = View.INVISIBLE
            cameraHint.visibility = View.VISIBLE
        } else {
            cameraHint.visibility = View.GONE
        }
    }

    private fun onScanned(text: String?) {
        if (text == null || AppState.mode != AppState.Mode.IDLE || hotspotFlow || safetyVisible) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastScanAt < 2500) return
        lastScanAt = now

        if (text == WifiQr.HOTSPOT_QR) {
            // Host is using its normal hotspot: friend picks it and types the password
            // in the Wi-Fi sheet, then the app joins as soon as the sheet closes.
            withMic {
                hotspotFlow = true
                pendingHotspotJoin = true
                showBanner("Tap the host's hotspot and type its password")
                if (!openWifiPanel()) {
                    pendingHotspotJoin = false
                    joinHotspotWhenReady(0)
                }
            }
            return
        }

        val wifi = WifiQr.parse(text)
        if (wifi == null) {
            showBanner("That's not a Convoy Talk QR code")
            return
        }
        withMic {
            if (!isWifiOn()) {
                showBanner("Turn on Wi-Fi, then scan again")
                openWifiPanel()
            } else {
                startIntercom(IntercomService.ACTION_JOIN_QR) {
                    it.putExtra(IntercomService.EXTRA_SSID, wifi.ssid)
                    it.putExtra(IntercomService.EXTRA_PASS, wifi.password)
                    it.putExtra(IntercomService.EXTRA_WPA3, wifi.wpa3)
                }
            }
        }
    }

    /** Waits up to 8 s for the Wi-Fi connection, then joins the host on it. */
    private fun joinHotspotWhenReady(tries: Int) {
        if (AppState.mode != AppState.Mode.IDLE) {
            hotspotFlow = false
            return
        }
        if (isOnWifiNetwork()) {
            hotspotFlow = false
            startIntercom(IntercomService.ACTION_JOIN_WIFI) { }
        } else if (tries < 16) {
            ui.postDelayed({ joinHotspotWhenReady(tries + 1) }, 500)
        } else {
            hotspotFlow = false
            showBanner("Not connected to the host's hotspot. Scan again to retry.")
        }
    }

    @Suppress("DEPRECATION")
    private fun isOnWifiNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.allNetworks.any {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    // ---------- Host ----------

    private fun onGenerate() {
        withMic {
            if (Build.VERSION.SDK_INT < 33 && !isLocationOn()) {
                askLocation()
            } else {
                startIntercom(IntercomService.ACTION_HOST) { }
            }
        }
    }

    private fun showHotspotDialog() {
        AlertDialog.Builder(this)
            .setTitle("Turn on your Hotspot")
            .setMessage(
                "Your phone couldn't make the app's own hotspot. Turn on your phone's Hotspot. " +
                    "Friends scan your QR code, then tap your hotspot and type its password."
            )
            .setPositiveButton("Open Hotspot settings") { _, _ -> openHotspotSettings() }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun askLocation() {
        AlertDialog.Builder(this)
            .setTitle("Turn on Location")
            .setMessage("Android needs Location turned on to create the hotspot. Turn it on, then tap GENERATE QR again.")
            .setPositiveButton("Turn on") { _, _ ->
                safeStart(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Helpers ----------

    private fun startIntercom(action: String, extras: (Intent) -> Unit) {
        val i = Intent(this, IntercomService::class.java)
            .setAction(action)
            .putExtra(IntercomService.EXTRA_NAME, deviceName())
        extras(i)
        ContextCompat.startForegroundService(this, i)
    }

    private fun stopIntercom() {
        startService(Intent(this, IntercomService::class.java).setAction(IntercomService.ACTION_STOP))
    }

    private fun deviceName(): String {
        val name = try {
            Settings.Global.getString(contentResolver, Settings.Global.DEVICE_NAME)
        } catch (e: Exception) {
            null
        }
        val clean = name?.trim()
        return if (clean.isNullOrEmpty()) Build.MODEL.take(30) else clean.take(30)
    }

    private fun neededPermissions(): List<String> {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
            list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return list
    }

    private fun hasPermission(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /** Runs the action once the microphone is allowed (asks if needed). */
    private fun withMic(action: () -> Unit) {
        if (hasPermission(Manifest.permission.RECORD_AUDIO)) {
            action()
            return
        }
        pendingAction = action
        permissionLauncher.launch(neededPermissions().filter { !hasPermission(it) }.toTypedArray())
    }

    private fun isWifiOn(): Boolean {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return wm.isWifiEnabled
    }

    private fun isLocationOn(): Boolean {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.isLocationEnabled
    }

    /** On opening the app, ask once to turn on Wi-Fi (slides up from the bottom). */
    private fun askWifiOnce() {
        if (askedWifi) return
        askedWifi = true
        if (!isWifiOn()) openWifiPanel()
    }

    /**
     * Asks once to let the app run freely in the background, so phones that
     * close background apps (common on Oppo, Vivo, Realme, Xiaomi) keep it on.
     */
    private fun askBatteryOnce() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (prefs.getBoolean("askedBattery", false)) return
        prefs.edit().putBoolean("askedBattery", true).apply()
        @Suppress("BatteryLife")
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.parse("package:$packageName"))
        safeStart(intent)
    }

    private fun openWifiPanel(): Boolean {
        return safeStart(Intent(Settings.Panel.ACTION_WIFI)) || safeStart(Intent(Settings.ACTION_WIFI_SETTINGS))
    }

    private fun openHotspotSettings() {
        val tether = Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
        if (!safeStart(tether)) {
            if (!safeStart(Intent(Settings.ACTION_WIRELESS_SETTINGS))) {
                safeStart(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    private fun safeStart(intent: Intent): Boolean {
        return try {
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
