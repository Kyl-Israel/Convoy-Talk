package com.convoytalk.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {

    private lateinit var nameInput: EditText
    private lateinit var statusText: TextView
    private lateinit var infoText: TextView
    private lateinit var membersText: TextView
    private lateinit var qrImage: ImageView

    private val ui = Handler(Looper.getMainLooper())
    private var shownQr: String? = null
    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val micOk = result[Manifest.permission.RECORD_AUDIO] == true || hasPermission(Manifest.permission.RECORD_AUDIO)
            val action = pendingAction
            pendingAction = null
            if (micOk) {
                action?.invoke()
            } else {
                toast("Microphone permission is needed to talk.")
            }
        }

    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        val text = result.contents
        if (text != null) {
            val wifi = WifiQr.parse(text)
            if (wifi == null) {
                toast("That is not a host QR code.")
            } else {
                startIntercom(IntercomService.ACTION_JOIN_QR) {
                    it.putExtra(IntercomService.EXTRA_SSID, wifi.ssid)
                    it.putExtra(IntercomService.EXTRA_PASS, wifi.password)
                    it.putExtra(IntercomService.EXTRA_WPA3, wifi.wpa3)
                }
            }
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            refreshUi()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameInput = findViewById(R.id.nameInput)
        statusText = findViewById(R.id.statusText)
        infoText = findViewById(R.id.infoText)
        membersText = findViewById(R.id.membersText)
        qrImage = findViewById(R.id.qrImage)

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        nameInput.setText(prefs.getString("name", ""))

        findViewById<Button>(R.id.hostButton).setOnClickListener {
            withPermissions { startIntercom(IntercomService.ACTION_HOST) { } }
        }
        findViewById<Button>(R.id.joinQrButton).setOnClickListener {
            withPermissions {
                val options = ScanOptions()
                    .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    .setPrompt("Scan the host's QR code")
                    .setBeepEnabled(false)
                    .setOrientationLocked(false)
                scanLauncher.launch(options)
            }
        }
        findViewById<Button>(R.id.joinWifiButton).setOnClickListener {
            withPermissions { startIntercom(IntercomService.ACTION_JOIN_WIFI) { } }
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            val i = Intent(this, IntercomService::class.java).setAction(IntercomService.ACTION_STOP)
            startService(i)
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(refresher)
        saveName()
    }

    private fun saveName() {
        getSharedPreferences("settings", Context.MODE_PRIVATE)
            .edit()
            .putString("name", nameInput.text.toString().trim())
            .apply()
    }

    private fun startIntercom(action: String, extras: (Intent) -> Unit) {
        saveName()
        val i = Intent(this, IntercomService::class.java)
            .setAction(action)
            .putExtra(IntercomService.EXTRA_NAME, nameInput.text.toString().trim())
        extras(i)
        ContextCompat.startForegroundService(this, i)
    }

    private fun neededPermissions(): Array<String> {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
            list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return list.toTypedArray()
    }

    private fun hasPermission(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun withPermissions(action: () -> Unit) {
        val missing = neededPermissions().filter { !hasPermission(it) }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun refreshUi() {
        statusText.text = AppState.status

        val info = StringBuilder()
        AppState.audioRoute?.let { info.append("Audio: ").append(it).append('\n') }
        AppState.wifiInfo?.let { info.append(it) }
        infoText.text = info.toString().trim()

        val members = AppState.members
        membersText.text = if (members.isEmpty()) "" else "In the room (${members.size}):\n" + members.joinToString("\n")

        val qr = AppState.qrText
        if (qr != shownQr) {
            shownQr = qr
            if (qr == null) {
                qrImage.visibility = View.GONE
                qrImage.setImageDrawable(null)
            } else {
                val bmp: Bitmap? = try {
                    BarcodeEncoder().encodeBitmap(qr, BarcodeFormat.QR_CODE, 700, 700)
                } catch (e: Exception) {
                    null
                }
                if (bmp != null) {
                    qrImage.setImageBitmap(bmp)
                    qrImage.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
