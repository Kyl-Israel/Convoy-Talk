package com.convoytalk.app

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Host: receives every friend's voice, mixes it, and sends each friend
 * everyone else's voice (never their own). The host also talks and listens.
 */
class HostServer(private val hostName: String) {

    private class Member(val addr: InetSocketAddress, @Volatile var name: String) {
        val jitter = JitterQueue(startFrames = 2, maxFrames = 6)
        @Volatile var lastSeen: Long = SystemClock.elapsedRealtime()
    }

    private val members = ConcurrentHashMap<InetSocketAddress, Member>()
    private val localJitter = JitterQueue(startFrames = 1, maxFrames = 4)
    private val player = SpeakerPlayer()
    private val mic = MicRecorder { frame ->
        if (frame != null) synchronized(localJitter) { localJitter.push(frame) }
    }
    private var socket: DatagramSocket? = null
    @Volatile private var running = false
    private var rxThread: Thread? = null
    private var mixThread: Thread? = null

    fun start() {
        val s = DatagramSocket(null)
        s.reuseAddress = true
        s.broadcast = true
        s.bind(InetSocketAddress(Protocol.PORT))
        socket = s
        running = true
        player.start()
        mic.start()
        rxThread = Thread({ receiveLoop(s) }, "host-rx").also { it.start() }
        mixThread = Thread({ mixLoop(s) }, "host-mix").also { it.start() }
        publishMembers()
    }

    /** Host tapped End: everyone hears the power-off sound right away. */
    fun announceEnd() {
        val s = socket ?: return
        val end = byteArrayOf(Protocol.MAGIC, Protocol.TYPE_END)
        for (m in members.values) {
            send(s, end, m.addr)
            send(s, end, m.addr)
        }
        player.playPowerOff()
    }

    fun stop() {
        running = false
        val s = socket
        if (s != null) {
            // Tell every friend the room is closed.
            val end = byteArrayOf(Protocol.MAGIC, Protocol.TYPE_END)
            for (m in members.values) {
                send(s, end, m.addr)
                send(s, end, m.addr)
            }
            s.close()
        }
        socket = null
        try { mixThread?.join(500) } catch (ignored: InterruptedException) { }
        try { rxThread?.join(500) } catch (ignored: InterruptedException) { }
        mic.stop()
        player.stop()
        members.clear()
    }

    private fun receiveLoop(s: DatagramSocket) {
        val buf = ByteArray(2048)
        while (running) {
            val p = DatagramPacket(buf, buf.size)
            try {
                s.receive(p)
            } catch (e: Exception) {
                if (!running) break
                continue
            }
            if (p.length < 2 || buf[0] != Protocol.MAGIC) continue
            val addr = p.socketAddress as? InetSocketAddress ?: continue
            val now = SystemClock.elapsedRealtime()
            when (buf[1]) {
                Protocol.TYPE_HELLO -> {
                    val name = String(buf, 2, p.length - 2, Charsets.UTF_8).trim().ifEmpty { "Friend" }
                    var isNew = false
                    val m = members.getOrPut(addr) {
                        isNew = true
                        Member(addr, name)
                    }
                    m.name = name
                    m.lastSeen = now
                    val welcome = byteArrayOf(Protocol.MAGIC, Protocol.TYPE_WELCOME) +
                        hostName.toByteArray(Charsets.UTF_8)
                    send(s, welcome, addr)
                    if (isNew) {
                        player.playChime()
                        AppState.post("$name connected")
                        publishMembers()
                    }
                }
                Protocol.TYPE_AUDIO -> {
                    val m = members[addr]
                    if (m != null && p.length >= 2 + Protocol.FRAME_BYTES) {
                        m.lastSeen = now
                        val frame = Protocol.bytesToShorts(buf, 2, Protocol.FRAME_SAMPLES)
                        synchronized(m.jitter) { m.jitter.push(frame) }
                    }
                }
                Protocol.TYPE_BYE -> {
                    val m = members.remove(addr)
                    if (m != null) {
                        player.playPowerOff()
                        AppState.post("${m.name} disconnected")
                        publishMembers()
                    }
                }
            }
        }
    }

    private fun mixLoop(s: DatagramSocket) {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
        val out = ByteArray(2 + Protocol.FRAME_BYTES)
        out[0] = Protocol.MAGIC
        out[1] = Protocol.TYPE_MIX
        var next = System.nanoTime()
        var lastMembersUpdate = 0L
        while (running) {
            next += 20_000_000L
            val now = SystemClock.elapsedRealtime()

            // Drop friends we have not heard from in 5 seconds.
            var changed = false
            val iter = members.entries.iterator()
            while (iter.hasNext()) {
                val entry = iter.next()
                if (now - entry.value.lastSeen > 5000) {
                    iter.remove()
                    AppState.post("${entry.value.name} disconnected")
                    changed = true
                }
            }
            if (changed) {
                player.playPowerOff()
                publishMembers()
            }

            val list = members.values.toList()
            val frames = arrayOfNulls<ShortArray>(list.size)
            for (i in list.indices) {
                val m = list[i]
                frames[i] = synchronized(m.jitter) { m.jitter.pop() }
            }
            val local = synchronized(localJitter) { localJitter.pop() }

            // Host hears all friends.
            mix(frames, -1, null)?.let { player.push(it) }

            // Each friend hears the host + everyone except themselves.
            for (i in list.indices) {
                val mixed = mix(frames, i, local) ?: continue
                Protocol.shortsToBytes(mixed, out, 2)
                send(s, out, list[i].addr)
            }

            if (now - lastMembersUpdate > 1000) {
                lastMembersUpdate = now
                publishMembers()
                val names = listOf(hostName) + list.map { it.name }
                val payload = names.joinToString("\n").toByteArray(Charsets.UTF_8)
                val packet = ByteArray(2 + payload.size)
                packet[0] = Protocol.MAGIC
                packet[1] = Protocol.TYPE_MEMBERS
                System.arraycopy(payload, 0, packet, 2, payload.size)
                for (m in list) send(s, packet, m.addr)
            }

            val sleepNs = next - System.nanoTime()
            if (sleepNs > 0) {
                try {
                    Thread.sleep(sleepNs / 1_000_000L, (sleepNs % 1_000_000L).toInt())
                } catch (e: InterruptedException) {
                    break
                }
            } else if (sleepNs < -200_000_000L) {
                next = System.nanoTime() // fell far behind, resync
            }
        }
    }

    /** Friends shown in the host's "Connected Devices" list. */
    private fun publishMembers() {
        AppState.members = members.values.map { it.name }
    }

    private fun mix(frames: Array<ShortArray?>, exclude: Int, extra: ShortArray?): ShortArray? {
        val acc = IntArray(Protocol.FRAME_SAMPLES)
        var any = false
        for (i in frames.indices) {
            if (i == exclude) continue
            val f = frames[i] ?: continue
            any = true
            for (k in 0 until Protocol.FRAME_SAMPLES) acc[k] += f[k].toInt()
        }
        if (extra != null) {
            any = true
            for (k in 0 until Protocol.FRAME_SAMPLES) acc[k] += extra[k].toInt()
        }
        if (!any) return null
        val out = ShortArray(Protocol.FRAME_SAMPLES)
        for (k in 0 until Protocol.FRAME_SAMPLES) {
            out[k] = acc[k].coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    private fun send(s: DatagramSocket, data: ByteArray, addr: InetSocketAddress) {
        try {
            s.send(DatagramPacket(data, data.size, addr))
        } catch (ignored: Exception) {
        }
    }
}
