package com.convoytalk.app

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Short, soft two-note chime played in the earphones when someone connects. */
object Chime {
    val frames: List<ShortArray> by lazy { build() }

    private fun build(): List<ShortArray> {
        val sr = Protocol.SAMPLE_RATE
        val total = (sr * 0.5).toInt()
        val pcm = DoubleArray(total)
        addNote(pcm, sr, 880.0, 0.00, 5200.0)    // A5
        addNote(pcm, sr, 1318.51, 0.12, 4600.0)  // E6

        // Fade out the last 60 ms so it ends smoothly.
        val fade = (sr * 0.06).toInt()
        for (i in 0 until fade) {
            val idx = total - fade + i
            pcm[idx] *= 1.0 - i.toDouble() / fade
        }

        val frames = ArrayList<ShortArray>()
        var i = 0
        while (i < total) {
            val f = ShortArray(Protocol.FRAME_SAMPLES)
            for (k in 0 until Protocol.FRAME_SAMPLES) {
                val idx = i + k
                if (idx < total) f[k] = pcm[idx].coerceIn(-32768.0, 32767.0).toInt().toShort()
            }
            frames.add(f)
            i += Protocol.FRAME_SAMPLES
        }
        return frames
    }

    private fun addNote(pcm: DoubleArray, sr: Int, freq: Double, start: Double, amp: Double) {
        val s0 = (start * sr).toInt()
        for (idx in s0 until pcm.size) {
            val t = (idx - s0).toDouble() / sr
            val attack = min(1.0, t / 0.006)
            val env = attack * exp(-t * 8.0)
            pcm[idx] += amp * env * (sin(2.0 * PI * freq * t) + 0.2 * sin(4.0 * PI * freq * t))
        }
    }
}
