package com.convoytalk.app

/** Shared status that the service writes and the screen reads. */
object AppState {
    @Volatile var status: String = "Not connected"
    @Volatile var audioRoute: String? = null
    @Volatile var qrText: String? = null
    @Volatile var wifiInfo: String? = null
    @Volatile var members: List<String> = emptyList()
}
