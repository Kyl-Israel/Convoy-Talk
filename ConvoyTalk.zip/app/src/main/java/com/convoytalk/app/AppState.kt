package com.convoytalk.app

import java.util.concurrent.ConcurrentLinkedQueue

/** Shared state that the service writes and the screen reads. */
object AppState {
    enum class Mode { IDLE, HOST_STARTING, HOSTING, JOINING, CONNECTED, RECONNECTING }

    @Volatile var mode: Mode = Mode.IDLE
    @Volatile var qrText: String? = null
    @Volatile var hostHint: String? = null
    @Volatile var hotspotHelp: Boolean = false
    @Volatile var members: List<String> = emptyList()

    /** Messages shown as pop-up banners on screen. */
    val events = ConcurrentLinkedQueue<String>()

    fun post(message: String) {
        events.add(message)
    }
}
