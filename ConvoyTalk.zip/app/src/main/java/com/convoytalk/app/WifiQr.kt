package com.convoytalk.app

/** Standard Wi-Fi QR format: WIFI:T:WPA;S:<name>;P:<password>;; */
data class WifiQr(val ssid: String, val password: String, val wpa3: Boolean) {

    fun toText(): String {
        val type = if (wpa3) "SAE" else "WPA"
        return "WIFI:T:$type;S:${escape(ssid)};P:${escape(password)};;"
    }

    companion object {
        private fun escape(s: String): String {
            val sb = StringBuilder()
            for (c in s) {
                if (c == '\\' || c == ';' || c == ',' || c == ':' || c == '"') sb.append('\\')
                sb.append(c)
            }
            return sb.toString()
        }

        fun parse(text: String): WifiQr? {
            if (!text.startsWith("WIFI:")) return null
            val fields = HashMap<String, String>()
            val sb = StringBuilder()
            var key: String? = null
            var i = 5
            while (i < text.length) {
                val c = text[i]
                if (c == '\\' && i + 1 < text.length) {
                    sb.append(text[i + 1])
                    i += 2
                    continue
                }
                if (key == null && c == ':') {
                    key = sb.toString()
                    sb.setLength(0)
                } else if (c == ';') {
                    val k = key
                    if (k != null) fields[k] = sb.toString()
                    key = null
                    sb.setLength(0)
                } else {
                    sb.append(c)
                }
                i++
            }
            val ssid = fields["S"] ?: return null
            if (ssid.isEmpty()) return null
            return WifiQr(ssid, fields["P"] ?: "", fields["T"] == "SAE")
        }
    }
}
