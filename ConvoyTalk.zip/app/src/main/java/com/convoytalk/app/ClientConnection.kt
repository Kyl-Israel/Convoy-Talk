package com.convoytalk.app

import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress

/**
 * Friend side: finds the host on the hotspot, sends mic audio to it,
 * and plays the mix that comes back.
 */
class ClientConnection(
    private val name: String,
    private val gateway: InetAddress?,
    private val onHostEnded: () -> Unit
) {
    private var socket: DatagramSocket? = null
    @Volatile private var hostAddr: InetSocketAddress? = null
    @Volatile private var lastFromHost = 0L
    @Volatile private var running = false
    @Volatile private var ended = false
    @Volatile private var leaving = false
    @Volatile private var lastMembers: List<String>? = null
    private val player = SpeakerPlayer()
    private val out = ByteArray(2 + Protocol.FRAME_BYTES)
    private val mic = MicRecorder { frame -> sendAudio(frame) }
    private var rxThread: Thread? = null
    private var helloThread: Thread? = null

    fun start() {
        val s = DatagramSocket()
        s.broadcast = true
        socket = s
        out[0] = Protocol.MAGIC
        out[1] = Protocol.TYPE_AUDIO
        running = true
        player.start()
        mic.start()
        rxThread = Thread({ receiveLoop(s) }, "client-rx").also { it.start() }
        helloThread = Thread({ helloLoop(s) }, "client-hello").also { it.start() }
    }

    /** Friend tapped Disconnect: tell the host now and play the power-off sound. */
    fun leave() {
        leaving = true
        sendBye()
        player.playPowerOff()
    }

    /** Android blocks network sends on the main thread, so send from a short-lived thread. */
    private fun sendBye() {
        val s = socket ?: return
        val h = hostAddr ?: return
        val bye = byteArrayOf(Protocol.MAGIC, Protocol.TYPE_BYE)
        val t = Thread({
            send(s, bye, h)
            send(s, bye, h)
        }, "client-bye")
        t.start()
        try { t.join(300) } catch (ignored: InterruptedException) { }
    }

    fun stop() {
        if (!leaving) sendBye()
        running = false
        val s = socket
        helloThread?.interrupt()
        s?.close()
        socket = null
        try { rxThread?.join(500) } catch (ignored: InterruptedException) { }
        mic.stop()
        player.stop()
    }

    private fun helloLoop(s: DatagramSocket) {
        val hello = byteArrayOf(Protocol.MAGIC, Protocol.TYPE_HELLO) + name.toByteArray(Charsets.UTF_8)
        val broadcast = try {
            InetSocketAddress(InetAddress.getByName("255.255.255.255"), Protocol.PORT)
        } catch (e: Exception) {
            null
        }
        while (running && !leaving) {
            val h = hostAddr
            if (h != null) {
                send(s, hello, h)
                if (SystemClock.elapsedRealtime() - lastFromHost > 5000) {
                    hostAddr = null
                    AppState.mode = AppState.Mode.RECONNECTING
                    AppState.post("Connection lost. Reconnecting…")
                    player.playPowerOff()
                }
            } else {
                if (gateway != null) send(s, hello, InetSocketAddress(gateway, Protocol.PORT))
                if (broadcast != null) send(s, hello, broadcast)
            }
            try {
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun receiveLoop(s: DatagramSocket) {
        val buf = ByteArray(4096)
        while (running) {
            val p = DatagramPacket(buf, buf.size)
            try {
                s.receive(p)
            } catch (e: Exception) {
                if (!running) break
                continue
            }
            if (p.length < 2 || buf[0] != Protocol.MAGIC) continue
            val from = p.socketAddress as? InetSocketAddress ?: continue
            when (buf[1]) {
                Protocol.TYPE_WELCOME -> {
                    if (leaving) continue
                    val first = hostAddr == null
                    hostAddr = from
                    lastFromHost = SystemClock.elapsedRealtime()
                    if (first) {
                        val hostName = if (p.length > 2) String(buf, 2, p.length - 2, Charsets.UTF_8) else "host"
                        AppState.mode = AppState.Mode.CONNECTED
                        AppState.post("Connected to $hostName")
                        player.playChime()
                    }
                }
                Protocol.TYPE_MIX -> {
                    if (from == hostAddr && p.length >= 2 + Protocol.FRAME_BYTES) {
                        lastFromHost = SystemClock.elapsedRealtime()
                        player.push(Protocol.bytesToShorts(buf, 2, Protocol.FRAME_SAMPLES))
                    }
                }
                Protocol.TYPE_MEMBERS -> {
                    if (from == hostAddr) {
                        lastFromHost = SystemClock.elapsedRealtime()
                        val text = String(buf, 2, p.length - 2, Charsets.UTF_8)
                        onMembers(text.split("\n").filter { it.isNotBlank() })
                    }
                }
                Protocol.TYPE_END -> {
                    if (!ended) {
                        ended = true
                        player.playPowerOff()
                        onHostEnded()
                    }
                }
            }
        }
    }

    /** Shows "X connected" / "X left" when the group changes. */
    private fun onMembers(names: List<String>) {
        val prev = lastMembers
        if (prev != null) {
            val added = names.toMutableList()
            for (n in prev) added.remove(n)
            val left = prev.toMutableList()
            for (n in names) left.remove(n)
            for (n in added) AppState.post("$n connected")
            for (n in left) AppState.post("$n left")
            if (added.isNotEmpty()) {
                player.playChime()
            } else if (left.isNotEmpty()) {
                player.playPowerOff()
            }
        }
        lastMembers = names
        AppState.members = names
    }

    private fun sendAudio(frame: ShortArray?) {
        if (frame == null || leaving) return
        val s = socket ?: return
        val h = hostAddr ?: return
        Protocol.shortsToBytes(frame, out, 2)
        send(s, out, h)
    }

    private fun send(s: DatagramSocket, data: ByteArray, addr: InetSocketAddress) {
        try {
            s.send(DatagramPacket(data, data.size, addr))
        } catch (ignored: Exception) {
        }
    }
}
