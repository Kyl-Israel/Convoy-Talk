package com.convoytalk.app

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Short sounds played in the earphones, built in code (no sound files needed). */
object Sounds {
    /** Rising two-note chime: someone connected. */
    val connect: List<ShortArray> by lazy {
        build(listOf(Note(880.0, 0.00, 5200.0), Note(1318.51, 0.12, 4600.0)), decay = 8.0)
    }

    /** Soft falling two-note "power off": someone disconnected or the host ended. */
    val disconnect: List<ShortArray> by lazy {
        build(listOf(Note(987.77, 0.00, 4200.0), Note(659.26, 0.12, 4000.0)), decay = 9.0)
    }

    private class Note(val freq: Double, val start: Double, val amp: Double)

    private fun build(notes: List<Note>, decay: Double): List<ShortArray> {
        val sr = Protocol.SAMPLE_RATE
        val total = (sr * 0.5).toInt()
        val pcm = DoubleArray(total)
        for (n in notes) {
            val s0 = (n.start * sr).toInt()
            for (idx in s0 until total) {
                val t = (idx - s0).toDouble() / sr
                val env = min(1.0, t / 0.006) * exp(-t * decay)
                pcm[idx] += n.amp * env * (sin(2.0 * PI * n.freq * t) + 0.2 * sin(4.0 * PI * n.freq * t))
            }
        }
        // Fade out the last 60 ms so it ends smoothly.
        val fade = (sr * 0.06).toInt()
        for (i in 0 until fade) {
            pcm[total - fade + i] *= 1.0 - i.toDouble() / fade
        }
        val frames = ArrayList<ShortArray>()
        var i = 0
        while (i < total) {
            val f = ShortArray(Protocol.FRAME_SAMPLES)
            for (k in 0 until Protocol.FRAME_SAMPLES) {
                val idx = i + k
                if (idx < total) f[k] = pcm[idx].coerceIn(-32768.0, 32767.0).toInt().toShort()
            }
            frames.add(f)
            i += Protocol.FRAME_SAMPLES
        }
        return frames
    }
}
