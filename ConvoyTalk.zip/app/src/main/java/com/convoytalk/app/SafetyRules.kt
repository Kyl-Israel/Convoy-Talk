package com.convoytalk.app

import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.graphics.Typeface

/** The safety rules shown on first launch and from the info button. */
object SafetyRules {
    private val rules = listOf(
        "Set up the app (host, scan, connect) while parked, never while driving.",
        "Mount your phone in a holder or keep it in your pocket. Never hold it while driving.",
        "Agree on a regroup point, like a gas station, before the trip in case anyone gets separated.",
        "Never look at or touch your phone while driving. Let a passenger handle it, or pull over safely first.",
        "Keep one ear free and the volume low enough to hear horns, sirens and traffic.",
        "Keep talk short and useful, like \"slowing down\", \"turning left ahead\" or \"pothole on the right\".",
        "Stop talking at intersections, in heavy traffic and in bad weather.",
        "Don't speed up to reconnect. The app reconnects lost members by itself once they're close again.",
        "Motorcycle riders: use earphones or a headset that fits safely under a properly worn helmet. Never loosen or remove the helmet to adjust them.",
        "Follow the Anti-Distracted Driving Act (RA 10913): only hands-free devices are allowed, and they must not block your view of the road.",
        "Convoy Talk is not an emergency service. In an accident, call 911.",
        "If someone suddenly goes silent or drops off, don't turn around on the road. Pull over safely first, then try to reach them.",
        "Your safety is our top priority, always use this app responsibly."
    )

    fun text(): CharSequence {
        val sb = SpannableStringBuilder()
        for ((i, rule) in rules.withIndex()) {
            if (i > 0) sb.append("\n\n")
            val start = sb.length
            sb.append("${i + 1}. ")
            sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append(rule)
        }
        return sb
    }
}
