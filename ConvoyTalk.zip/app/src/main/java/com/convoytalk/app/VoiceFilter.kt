package com.convoytalk.app

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Cleans and levels the mic, always on (no button):
 * 1. High-pass filter at 100 Hz removes engine and road rumble.
 * 2. Auto volume: quiet voices are boosted (up to 10x), loud ones are kept from clipping.
 * 3. Voice detection: sends audio while someone is talking. It is lenient,
 *    keeps sending through short pauses, and includes the 60 ms just before
 *    speech starts, so first words and soft voices are not cut off.
 * The phone's own noise suppressor (and the earbuds' one) does the heavy noise removal.
 */
class VoiceFilter {
    companion object {
        private const val TARGET_RMS = 3500.0   // comfortable speaking level
        private const val MAX_GAIN = 10.0
        private const val MIN_SPEECH_RMS = 120.0
        private const val SPEECH_OVER_NOISE = 2.2
        private const val HANGOVER_FRAMES = 35  // keep sending 700 ms after the last word
        private const val PREROLL_FRAMES = 3    // send the 60 ms before speech starts
    }

    private val b0: Double
    private val b1: Double
    private val b2: Double
    private val a1: Double
    private val a2: Double
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    private val work = DoubleArray(Protocol.FRAME_SAMPLES)
    private var noiseFloor = 100.0
    private var talking = false
    private var hangover = 0
    private var gain = 2.0
    private val preroll = ArrayDeque<ShortArray>()

    init {
        val f0 = 100.0
        val q = 0.707
        val w0 = 2.0 * Math.PI * f0 / Protocol.SAMPLE_RATE
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        val a0 = 1.0 + alpha
        b0 = ((1.0 + c) / 2.0) / a0
        b1 = (-(1.0 + c)) / a0
        b2 = ((1.0 + c) / 2.0) / a0
        a1 = (-2.0 * c) / a0
        a2 = (1.0 - alpha) / a0
    }

    /** Returns the frames to send now (empty while nobody is talking). */
    fun process(frame: ShortArray): List<ShortArray> {
        val n = frame.size
        var sumSq = 0.0
        for (i in 0 until n) {
            val x = frame[i].toDouble()
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            work[i] = y
            sumSq += y * y
        }
        val rms = sqrt(sumSq / n)

        val speech = rms > maxOf(noiseFloor * SPEECH_OVER_NOISE, MIN_SPEECH_RMS)

        // Learn the background noise. While talking it barely moves,
        // so a long sentence never "learns" the voice as noise.
        noiseFloor = if (rms < noiseFloor) {
            if (talking) noiseFloor * 0.9 + rms * 0.1 else noiseFloor * 0.8 + rms * 0.2
        } else {
            if (talking) noiseFloor * 0.998 + rms * 0.002 else noiseFloor * 0.99 + rms * 0.01
        }
        if (noiseFloor < 20.0) noiseFloor = 20.0

        // Auto volume, adjusted only on speech. Turns down fast, up slowly.
        val prevGain = gain
        if (speech) {
            val wanted = (TARGET_RMS / maxOf(rms, 1.0)).coerceIn(1.0, MAX_GAIN)
            gain += (wanted - gain) * (if (wanted < gain) 0.4 else 0.12)
        }
        val out = ShortArray(n)
        for (i in 0 until n) {
            val g = prevGain + (gain - prevGain) * i / n
            out[i] = Protocol.softClip(work[i] * g)
        }

        val result = ArrayList<ShortArray>(PREROLL_FRAMES + 1)
        if (!talking) {
            if (speech) {
                talking = true
                hangover = HANGOVER_FRAMES
                val first = preroll.firstOrNull() ?: out
                fade(first, fadeIn = true)
                result.addAll(preroll)
                preroll.clear()
                result.add(out)
            } else {
                preroll.addLast(out)
                while (preroll.size > PREROLL_FRAMES) preroll.removeFirst()
            }
        } else {
            if (speech) hangover = HANGOVER_FRAMES else hangover--
            if (hangover <= 0) {
                fade(out, fadeIn = false)
                talking = false
            }
            result.add(out)
        }
        return result
    }

    private fun fade(f: ShortArray, fadeIn: Boolean) {
        val n = f.size
        for (i in 0 until n) {
            val k = if (fadeIn) i.toDouble() / n else 1.0 - i.toDouble() / n
            f[i] = (f[i] * k).toInt().toShort()
        }
    }
}
