package com.convoytalk.app

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Automatic noise filter, always on (no button):
 * 1. High-pass filter at 150 Hz removes engine and road rumble.
 * 2. Noise gate learns the background noise level and only lets
 *    sound through when it is clearly louder than the noise (talking).
 */
class VoiceFilter {
    private val b0: Double
    private val b1: Double
    private val b2: Double
    private val a1: Double
    private val a2: Double
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    private val work = DoubleArray(Protocol.FRAME_SAMPLES)
    private var noiseFloor = 300.0
    private var hangover = 0
    private var gain = 0.0

    init {
        val f0 = 150.0
        val q = 0.707
        val w0 = 2.0 * Math.PI * f0 / Protocol.SAMPLE_RATE
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        val a0 = 1.0 + alpha
        b0 = ((1.0 + c) / 2.0) / a0
        b1 = (-(1.0 + c)) / a0
        b2 = ((1.0 + c) / 2.0) / a0
        a1 = (-2.0 * c) / a0
        a2 = (1.0 - alpha) / a0
    }

    /** Cleans the frame in place. Returns true if it contains talking. */
    fun process(frame: ShortArray): Boolean {
        var sumSq = 0.0
        for (i in frame.indices) {
            val x = frame[i].toDouble()
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = x
            y2 = y1
            y1 = y
            work[i] = y
            sumSq += y * y
        }
        val rms = sqrt(sumSq / frame.size)

        // Learn background noise: drops fast, rises slowly.
        noiseFloor = if (rms < noiseFloor) {
            noiseFloor * 0.90 + rms * 0.10
        } else {
            noiseFloor * 0.997 + rms * 0.003
        }
        if (noiseFloor < 60.0) noiseFloor = 60.0

        val talking = rms > noiseFloor * 2.5 && rms > 350.0
        if (talking) {
            hangover = 20 // keep open 400 ms after last word
        } else if (hangover > 0) {
            hangover--
        }

        val target = if (talking || hangover > 0) 1.0 else 0.0
        val openStep = 1.0 / frame.size
        val closeStep = 0.5 / frame.size
        for (i in frame.indices) {
            if (gain < target) {
                gain = minOf(target, gain + openStep)
            } else if (gain > target) {
                gain = maxOf(target, gain - closeStep)
            }
            val v = (work[i] * gain).coerceIn(-32768.0, 32767.0)
            frame[i] = v.toInt().toShort()
        }
        return gain > 0.001 || target > 0.0
    }
}
