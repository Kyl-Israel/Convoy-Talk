package com.convoytalk.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.net.Inet4Address
import java.net.InetAddress

/** Keeps the intercom running in the background with the screen off. */
class IntercomService : Service() {

    companion object {
        const val ACTION_HOST = "com.convoytalk.app.HOST"
        const val ACTION_JOIN_QR = "com.convoytalk.app.JOIN_QR"
        const val ACTION_JOIN_WIFI = "com.convoytalk.app.JOIN_WIFI"
        const val ACTION_STOP = "com.convoytalk.app.STOP"
        const val EXTRA_NAME = "name"
        const val EXTRA_SSID = "ssid"
        const val EXTRA_PASS = "pass"
        const val EXTRA_WPA3 = "wpa3"
        private const val CHANNEL_ID = "intercom"
        private const val NOTIFICATION_ID = 1
        private const val WIFI_TIMEOUT_MS = 60_000
        private const val FIND_HOST_TIMEOUT_MS = 20_000L
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var cm: ConnectivityManager
    private lateinit var wm: WifiManager

    private var host: HostServer? = null
    private var client: ClientConnection? = null
    private var router: BluetoothRouter? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var session = 0

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (intent == null || action == null || action == ACTION_STOP) {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            goForeground()
        } catch (e: Exception) {
            AppState.post("Couldn't start: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        shutdown()
        session++
        acquireLocks()
        val name = intent.getStringExtra(EXTRA_NAME)?.trim()?.ifEmpty { null } ?: "Friend"
        when (action) {
            ACTION_HOST -> startHost(name)
            ACTION_JOIN_QR -> joinWithQr(
                name,
                intent.getStringExtra(EXTRA_SSID) ?: "",
                intent.getStringExtra(EXTRA_PASS) ?: "",
                intent.getBooleanExtra(EXTRA_WPA3, false)
            )
            ACTION_JOIN_WIFI -> joinCurrentWifi(name)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    /** Stops everything, shows a message, and returns the app to the scan screen. */
    private fun fail(message: String) {
        shutdown()
        AppState.post(message)
        stopSelf()
    }

    // ---------- Host ----------

    private fun startHost(name: String) {
        AppState.mode = AppState.Mode.HOST_STARTING
        val mySession = session
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation?) {
                    if (mySession != session) {
                        res?.close()
                        return
                    }
                    if (res == null) {
                        useNormalHotspot(name, true)
                        return
                    }
                    reservation = res
                    val qr = readHotspot(res)
                    if (qr == null) {
                        useNormalHotspot(name, true)
                        return
                    }
                    AppState.qrText = qr.toText()
                    AppState.hostHint = null
                    startHostAudio(name)
                }

                override fun onStopped() {
                    if (mySession == session) fail("The hotspot turned off. Tap GENERATE QR again.")
                }

                override fun onFailed(reason: Int) {
                    if (mySession != session) return
                    // INCOMPATIBLE_MODE = the phone's normal hotspot is already on, so just use it.
                    useNormalHotspot(name, reason != WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE)
                }
            }, main)
        } catch (e: Exception) {
            useNormalHotspot(name, true)
        }
    }

    /** Backup plan: friends join the phone's normal hotspot, then scan. */
    private fun useNormalHotspot(name: String, askToTurnOn: Boolean) {
        AppState.qrText = WifiQr.HOTSPOT_QR
        AppState.hostHint = "Friends: connect to this phone's hotspot in Wi-Fi settings, then scan."
        if (askToTurnOn) AppState.hotspotHelp = true
        startHostAudio(name)
    }

    private fun startHostAudio(name: String) {
        if (host != null) return
        try {
            val r = BluetoothRouter(this)
            r.start()
            router = r
            val h = HostServer(name)
            h.start()
            host = h
            AppState.mode = AppState.Mode.HOSTING
        } catch (e: Exception) {
            fail("Couldn't start: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun readHotspot(res: WifiManager.LocalOnlyHotspotReservation): WifiQr? {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val c: SoftApConfiguration = res.softApConfiguration
                val ssid = if (Build.VERSION.SDK_INT >= 33) {
                    c.wifiSsid?.toString()?.removeSurrounding("\"") ?: ""
                } else {
                    c.ssid ?: ""
                }
                val pass = c.passphrase ?: ""
                val wpa3 = c.securityType == SoftApConfiguration.SECURITY_TYPE_WPA3_SAE
                if (ssid.isEmpty()) null else WifiQr(ssid, pass, wpa3)
            } else {
                val c = res.wifiConfiguration ?: return null
                val ssid = c.SSID?.removeSurrounding("\"") ?: ""
                val pass = c.preSharedKey?.removeSurrounding("\"") ?: ""
                if (ssid.isEmpty()) null else WifiQr(ssid, pass, false)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Join ----------

    private fun joinWithQr(name: String, ssid: String, pass: String, wpa3: Boolean) {
        if (ssid.isEmpty()) {
            fail("That QR code didn't work. Scan again.")
            return
        }
        AppState.mode = AppState.Mode.JOINING
        val specBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
        if (pass.isNotEmpty()) {
            if (wpa3) specBuilder.setWpa3Passphrase(pass) else specBuilder.setWpa2Passphrase(pass)
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(specBuilder.build())
            .build()
        val mySession = session
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                main.post {
                    if (mySession == session) startClient(name, network)
                }
            }

            override fun onLost(network: Network) {
                main.post {
                    if (mySession == session && AppState.mode == AppState.Mode.CONNECTED) {
                        AppState.mode = AppState.Mode.RECONNECTING
                    }
                }
            }

            override fun onUnavailable() {
                main.post {
                    if (mySession == session) fail("Couldn't reach the host. Move closer and scan again.")
                }
            }
        }
        netCallback = cb
        try {
            cm.requestNetwork(request, cb, WIFI_TIMEOUT_MS)
        } catch (e: Exception) {
            netCallback = null
            fail("Couldn't connect: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun joinCurrentWifi(name: String) {
        val wifi = cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
        if (wifi == null) {
            fail("Connect to the host's hotspot in Wi-Fi settings first, then scan again.")
            return
        }
        AppState.mode = AppState.Mode.JOINING
        startClient(name, wifi)
    }

    private fun startClient(name: String, network: Network) {
        client?.stop()
        client = null
        router?.stop()
        router = null
        val mySession = session
        try {
            cm.bindProcessToNetwork(network)
            val r = BluetoothRouter(this)
            r.start()
            router = r
            val c = ClientConnection(name, findGateway(network)) {
                main.post {
                    if (mySession == session) fail("The host ended the connection.")
                }
            }
            c.start()
            client = c
        } catch (e: Exception) {
            fail("Couldn't join: ${e.message}")
            return
        }
        main.postDelayed({
            if (mySession == session && AppState.mode == AppState.Mode.JOINING) {
                fail("Host not found. Make sure you scanned the host's QR code.")
            }
        }, FIND_HOST_TIMEOUT_MS)
    }

    private fun findGateway(network: Network): InetAddress? {
        val lp = cm.getLinkProperties(network) ?: return null
        if (Build.VERSION.SDK_INT >= 30) {
            val dhcp = lp.dhcpServerAddress
            if (dhcp != null) return dhcp
        }
        for (route in lp.routes) {
            val g = route.gateway
            if (g is Inet4Address && !g.isAnyLocalAddress) return g
        }
        return null
    }

    // ---------- Shared ----------

    private fun shutdown() {
        session++
        client?.stop()
        client = null
        host?.stop()
        host = null
        router?.stop()
        router = null
        try { reservation?.close() } catch (ignored: Exception) { }
        reservation = null
        netCallback?.let {
            try { cm.unregisterNetworkCallback(it) } catch (ignored: Exception) { }
        }
        netCallback = null
        try { cm.bindProcessToNetwork(null) } catch (ignored: Exception) { }
        releaseLocks()
        AppState.mode = AppState.Mode.IDLE
        AppState.qrText = null
        AppState.hostHint = null
        AppState.hotspotHelp = false
        AppState.members = emptyList()
    }

    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ConvoyTalk:audio").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "ConvoyTalk:wifi").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (ignored: Exception) {
        }
    }

    private fun releaseLocks() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) { }
        wakeLock = null
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) { }
        wifiLock = null
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Intercom", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Convoy Talk is on")
            .setContentText("Your mic is live to the group")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }
}
