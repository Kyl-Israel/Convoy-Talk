package com.convoytalk.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.net.Inet4Address
import java.net.InetAddress

/** Keeps the intercom running in the background with the screen off. */
class IntercomService : Service() {

    companion object {
        const val ACTION_HOST = "com.convoytalk.app.HOST"
        const val ACTION_JOIN_QR = "com.convoytalk.app.JOIN_QR"
        const val ACTION_JOIN_WIFI = "com.convoytalk.app.JOIN_WIFI"
        const val ACTION_STOP = "com.convoytalk.app.STOP"
        const val EXTRA_NAME = "name"
        const val EXTRA_SSID = "ssid"
        const val EXTRA_PASS = "pass"
        const val EXTRA_WPA3 = "wpa3"
        private const val CHANNEL_ID = "intercom"
        private const val NOTIFICATION_ID = 1
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var cm: ConnectivityManager
    private lateinit var wm: WifiManager

    private var host: HostServer? = null
    private var client: ClientConnection? = null
    private var router: BluetoothRouter? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var session = 0

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (intent == null || action == null || action == ACTION_STOP) {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            goForeground()
        } catch (e: Exception) {
            AppState.status = "Could not start: ${e.message}"
            stopSelf()
            return START_NOT_STICKY
        }

        shutdown()
        session++
        acquireLocks()
        val name = intent.getStringExtra(EXTRA_NAME)?.trim()?.ifEmpty { null } ?: "Friend"
        when (action) {
            ACTION_HOST -> startHost(name)
            ACTION_JOIN_QR -> joinWithQr(
                name,
                intent.getStringExtra(EXTRA_SSID) ?: "",
                intent.getStringExtra(EXTRA_PASS) ?: "",
                intent.getBooleanExtra(EXTRA_WPA3, false)
            )
            ACTION_JOIN_WIFI -> joinCurrentWifi(name)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ---------- Host ----------

    private fun startHost(name: String) {
        AppState.status = "Starting hotspot…"
        val mySession = session
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation?) {
                    if (mySession != session) {
                        res?.close()
                        return
                    }
                    if (res == null) {
                        startHostAudio(name, "Hotspot did not start. Tap Host again.")
                        return
                    }
                    reservation = res
                    val qr = readHotspot(res)
                    if (qr != null) {
                        AppState.qrText = qr.toText()
                        AppState.wifiInfo = "Wi-Fi: ${qr.ssid}\nPassword: ${qr.password}"
                    }
                    startHostAudio(name, "Hosting. Friends scan this QR to join.")
                }

                override fun onStopped() {
                    if (mySession == session) {
                        AppState.status = "Hotspot stopped. Tap Host again."
                        AppState.qrText = null
                    }
                }

                override fun onFailed(reason: Int) {
                    if (mySession != session) return
                    startHostAudio(
                        name,
                        "App hotspot failed (code $reason). Turn on Location and turn off the normal " +
                            "hotspot, then tap Host again. Or turn on your normal hotspot and friends " +
                            "use \"Join (already on host Wi-Fi)\"."
                    )
                }
            }, main)
        } catch (e: Exception) {
            startHostAudio(
                name,
                "App hotspot not allowed (${e.message}). Turn on your normal hotspot and friends " +
                    "use \"Join (already on host Wi-Fi)\"."
            )
        }
    }

    private fun startHostAudio(name: String, status: String) {
        try {
            val r = BluetoothRouter(this)
            AppState.audioRoute = r.start()
            router = r
            val h = HostServer(name)
            h.start()
            host = h
            AppState.status = status
        } catch (e: Exception) {
            AppState.status = "Host error: ${e.message}"
        }
    }

    @Suppress("DEPRECATION")
    private fun readHotspot(res: WifiManager.LocalOnlyHotspotReservation): WifiQr? {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val c: SoftApConfiguration = res.softApConfiguration
                val ssid = if (Build.VERSION.SDK_INT >= 33) {
                    c.wifiSsid?.toString()?.removeSurrounding("\"") ?: ""
                } else {
                    c.ssid ?: ""
                }
                val pass = c.passphrase ?: ""
                val wpa3 = c.securityType == SoftApConfiguration.SECURITY_TYPE_WPA3_SAE
                if (ssid.isEmpty()) null else WifiQr(ssid, pass, wpa3)
            } else {
                val c = res.wifiConfiguration ?: return null
                val ssid = c.SSID?.removeSurrounding("\"") ?: ""
                val pass = c.preSharedKey?.removeSurrounding("\"") ?: ""
                if (ssid.isEmpty()) null else WifiQr(ssid, pass, false)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Join ----------

    private fun joinWithQr(name: String, ssid: String, pass: String, wpa3: Boolean) {
        if (ssid.isEmpty()) {
            AppState.status = "Bad QR code"
            return
        }
        AppState.status = "Connecting to $ssid… tap Connect on the Wi-Fi popup."
        val specBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
        if (pass.isNotEmpty()) {
            if (wpa3) specBuilder.setWpa3Passphrase(pass) else specBuilder.setWpa2Passphrase(pass)
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(specBuilder.build())
            .build()
        val mySession = session
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                main.post {
                    if (mySession != session) return@post
                    startClient(name, network)
                }
            }

            override fun onLost(network: Network) {
                main.post {
                    if (mySession == session) {
                        AppState.status = "Host Wi-Fi lost, move closer…"
                    }
                }
            }

            override fun onUnavailable() {
                main.post {
                    if (mySession == session) {
                        AppState.status = "Could not connect to host Wi-Fi. Move closer and scan again."
                    }
                }
            }
        }
        netCallback = cb
        try {
            cm.requestNetwork(request, cb)
        } catch (e: Exception) {
            netCallback = null
            AppState.status = "Wi-Fi request failed: ${e.message}"
        }
    }

    @Suppress("DEPRECATION")
    private fun joinCurrentWifi(name: String) {
        val wifi = cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
        if (wifi == null) {
            AppState.status = "Not on any Wi-Fi. Connect to the host's hotspot in Settings first."
            return
        }
        startClient(name, wifi)
    }

    private fun startClient(name: String, network: Network) {
        client?.stop()
        client = null
        router?.stop()
        router = null
        try {
            cm.bindProcessToNetwork(network)
            val r = BluetoothRouter(this)
            AppState.audioRoute = r.start()
            router = r
            val c = ClientConnection(name, findGateway(network))
            c.start()
            client = c
        } catch (e: Exception) {
            AppState.status = "Join error: ${e.message}"
        }
    }

    private fun findGateway(network: Network): InetAddress? {
        val lp = cm.getLinkProperties(network) ?: return null
        if (Build.VERSION.SDK_INT >= 30) {
            val dhcp = lp.dhcpServerAddress
            if (dhcp != null) return dhcp
        }
        for (route in lp.routes) {
            val g = route.gateway
            if (g is Inet4Address && !g.isAnyLocalAddress) return g
        }
        return null
    }

    // ---------- Shared ----------

    private fun shutdown() {
        client?.stop()
        client = null
        host?.stop()
        host = null
        router?.stop()
        router = null
        try { reservation?.close() } catch (ignored: Exception) { }
        reservation = null
        netCallback?.let {
            try { cm.unregisterNetworkCallback(it) } catch (ignored: Exception) { }
        }
        netCallback = null
        try { cm.bindProcessToNetwork(null) } catch (ignored: Exception) { }
        releaseLocks()
        AppState.status = "Not connected"
        AppState.audioRoute = null
        AppState.qrText = null
        AppState.wifiInfo = null
        AppState.members = emptyList()
    }

    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ConvoyTalk:audio").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "ConvoyTalk:wifi").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (ignored: Exception) {
        }
    }

    private fun releaseLocks() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) { }
        wakeLock = null
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) { }
        wifiLock = null
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Intercom", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Convoy Talk is on")
            .setContentText("Your mic is live to the group")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }
}
