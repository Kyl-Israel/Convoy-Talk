package com.convoytalk.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Process
import java.util.concurrent.LinkedBlockingDeque

/** Small buffer that smooths out network timing. One consumer thread only. */
class JitterQueue(private val startFrames: Int, private val maxFrames: Int) {
    private val queue = LinkedBlockingDeque<ShortArray>()
    private var buffering = true

    fun push(frame: ShortArray) {
        queue.offerLast(frame)
        while (queue.size > maxFrames) queue.pollFirst()
    }

    fun pop(): ShortArray? {
        if (buffering) {
            if (queue.size >= startFrames) buffering = false else return null
        }
        val f = queue.pollFirst()
        if (f == null) buffering = true
        return f
    }
}

/** Reads the mic in 20 ms frames, cleans them, and hands them out. Null = silence. */
class MicRecorder(private val onFrame: (ShortArray?) -> Unit) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private val effects = mutableListOf<AudioEffect>()

    @SuppressLint("MissingPermission")
    fun start() {
        val minBuf = AudioRecord.getMinBufferSize(
            Protocol.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            Protocol.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, Protocol.FRAME_BYTES * 4)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("Microphone not available")
        }
        val session = rec.audioSessionId
        try {
            if (NoiseSuppressor.isAvailable()) {
                NoiseSuppressor.create(session)?.let { it.setEnabled(true); effects.add(it) }
            }
            if (AcousticEchoCanceler.isAvailable()) {
                AcousticEchoCanceler.create(session)?.let { it.setEnabled(true); effects.add(it) }
            }
            if (AutomaticGainControl.isAvailable()) {
                AutomaticGainControl.create(session)?.let { it.setEnabled(true); effects.add(it) }
            }
        } catch (ignored: Exception) {
            // Effects are optional; the VoiceFilter still runs.
        }

        record = rec
        running = true
        rec.startRecording()
        thread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val filter = VoiceFilter()
            while (running) {
                val frame = ShortArray(Protocol.FRAME_SAMPLES)
                var read = 0
                while (read < Protocol.FRAME_SAMPLES && running) {
                    val n = rec.read(frame, read, Protocol.FRAME_SAMPLES - read)
                    if (n <= 0) break
                    read += n
                }
                if (!running) break
                if (read < Protocol.FRAME_SAMPLES) {
                    try { Thread.sleep(5) } catch (ignored: InterruptedException) { break }
                    continue
                }
                val talking = filter.process(frame)
                onFrame(if (talking) frame else null)
            }
        }, "mic").also { it.start() }
    }

    fun stop() {
        running = false
        try { thread?.join(500) } catch (ignored: InterruptedException) { }
        thread = null
        record?.let {
            try { it.stop() } catch (ignored: Exception) { }
            it.release()
        }
        record = null
        for (e in effects) {
            try { e.release() } catch (ignored: Exception) { }
        }
        effects.clear()
    }
}

/** Plays 20 ms frames through the call audio path (Bluetooth headset when routed). */
class SpeakerPlayer {
    private val jitter = JitterQueue(startFrames = 3, maxFrames = 8)
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    @Volatile private var requestedSound: List<ShortArray>? = null

    fun push(frame: ShortArray) {
        synchronized(jitter) { jitter.push(frame) }
    }

    /** Plays the connect chime in the earphones, on top of any voices. */
    fun playChime() {
        requestedSound = Sounds.connect
    }

    /** Plays the soft power-off sound in the earphones. */
    fun playPowerOff() {
        requestedSound = Sounds.disconnect
    }

    private fun mixFrames(voice: ShortArray?, extra: ShortArray): ShortArray {
        val out = ShortArray(Protocol.FRAME_SAMPLES)
        for (k in 0 until Protocol.FRAME_SAMPLES) {
            val v = (voice?.get(k)?.toInt() ?: 0) + extra[k].toInt()
            out[k] = v.coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    fun start() {
        val minBuf = AudioTrack.getMinBufferSize(
            Protocol.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(Protocol.SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, Protocol.FRAME_BYTES * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        running = true
        t.play()
        thread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val silence = ShortArray(Protocol.FRAME_SAMPLES)
            var sound: List<ShortArray>? = null
            var soundIndex = 0
            while (running) {
                val req = requestedSound
                if (req != null) {
                    requestedSound = null
                    sound = req
                    soundIndex = 0
                }
                val voice = synchronized(jitter) { jitter.pop() }
                var frame = voice ?: silence
                val s = sound
                if (s != null) {
                    frame = mixFrames(voice, s[soundIndex])
                    soundIndex++
                    if (soundIndex >= s.size) sound = null
                }
                val n = t.write(frame, 0, Protocol.FRAME_SAMPLES)
                if (n < 0) {
                    try { Thread.sleep(20) } catch (ignored: InterruptedException) { break }
                }
            }
        }, "speaker").also { it.start() }
    }

    fun stop() {
        running = false
        try { thread?.join(500) } catch (ignored: InterruptedException) { }
        thread = null
        track?.let {
            try { it.stop() } catch (ignored: Exception) { }
            it.release()
        }
        track = null
    }
}

/** Sends call audio (mic + earphones) to the Bluetooth headset. */
class BluetoothRouter(context: Context) {
    private val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Suppress("DEPRECATION")
    fun start(): String {
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT >= 31) {
            val devices = am.availableCommunicationDevices
            val bt = devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                ?: devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }
            if (bt != null && am.setCommunicationDevice(bt)) return "Bluetooth earphones"
            val wired = devices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            if (wired != null && am.setCommunicationDevice(wired)) return "Wired earphones"
            return "No earphones found, using phone earpiece"
        } else {
            if (am.isBluetoothScoAvailableOffCall) {
                am.startBluetoothSco()
                am.isBluetoothScoOn = true
                return "Bluetooth earphones (if connected)"
            }
            return "Phone audio"
        }
    }

    @Suppress("DEPRECATION")
    fun stop() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
            } else {
                am.isBluetoothScoOn = false
                am.stopBluetoothSco()
            }
        } catch (ignored: Exception) { }
        am.mode = AudioManager.MODE_NORMAL
    }
}
