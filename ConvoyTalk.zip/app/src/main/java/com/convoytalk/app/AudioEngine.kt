package com.convoytalk.app

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import androidx.core.content.ContextCompat
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.roundToInt

/** Which mic and speaker the call audio uses right now (earbuds, wired, or phone). */
object AudioRoute {
    @Volatile var input: AudioDeviceInfo? = null
    @Volatile var output: AudioDeviceInfo? = null
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    /** Tells the mic and player to switch to the new devices. */
    fun changed() {
        for (l in listeners) {
            try { l() } catch (ignored: Exception) { }
        }
    }
}

/**
 * Smooths out Wi-Fi timing. Grows its buffer when packets arrive late,
 * shrinks it again when the connection is steady, and covers a single
 * lost packet so the voice doesn't break up.
 */
class JitterQueue(private val minStart: Int, private val maxStart: Int) {
    private val queue = ArrayDeque<ShortArray>()
    private var target = minStart
    private var buffering = true
    private var last: ShortArray? = null
    private var concealed = 0
    private var stable = 0
    private var underrunAt = 0L

    @Synchronized
    fun push(frame: ShortArray) {
        if (buffering && underrunAt != 0L) {
            // Audio came back quickly after running dry: packets were late, not silence.
            if (SystemClock.elapsedRealtime() - underrunAt < 250) {
                target = minOf(target + 1, maxStart)
            }
            underrunAt = 0L
        }
        queue.addLast(frame)
        // Don't let delay pile up.
        if (queue.size > target + 6) {
            while (queue.size > target) queue.removeFirst()
        }
    }

    @Synchronized
    fun pop(): ShortArray? {
        if (buffering) {
            if (queue.size >= target) buffering = false else return null
        }
        val f = queue.removeFirstOrNull()
        if (f != null) {
            last = f
            concealed = 0
            stable++
            if (stable > 1500 && target > minStart) {
                target--
                stable = 0
            }
            return f
        }
        // Missing packet: softly repeat the last bit instead of a hard gap.
        val l = last
        if (l != null && concealed < 2) {
            concealed++
            val g = if (concealed == 1) 0.6 else 0.3
            return ShortArray(l.size) { (l[it] * g).toInt().toShort() }
        }
        buffering = true
        last = null
        stable = 0
        underrunAt = SystemClock.elapsedRealtime()
        return null
    }
}

/** Reads the mic in 20 ms frames, cleans and levels them, and hands them out. Null = silence. */
class MicRecorder(private val onFrame: (ShortArray?) -> Unit) {
    @Volatile private var running = false
    private var active = false
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private val effects = mutableListOf<AudioEffect>()
    private val routeListener: () -> Unit = { restart() }

    fun start() {
        active = true
        AudioRoute.addListener(routeListener)
        open()
    }

    fun stop() {
        active = false
        AudioRoute.removeListener(routeListener)
        close()
    }

    /** Earbuds connected/disconnected: reopen the mic on the new device. */
    private fun restart() {
        if (!active) return
        close()
        try {
            open()
        } catch (ignored: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    private fun open() {
        val minBuf = AudioRecord.getMinBufferSize(
            Protocol.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            Protocol.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf * 2, Protocol.FRAME_BYTES * 10)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("Microphone not available")
        }
        // Use the earbuds' mic when they are connected.
        try { rec.setPreferredDevice(AudioRoute.input) } catch (ignored: Exception) { }
        val session = rec.audioSessionId
        try {
            if (NoiseSuppressor.isAvailable()) {
                NoiseSuppressor.create(session)?.let { it.setEnabled(true); effects.add(it) }
            }
            if (AcousticEchoCanceler.isAvailable()) {
                AcousticEchoCanceler.create(session)?.let { it.setEnabled(true); effects.add(it) }
            }
        } catch (ignored: Exception) {
        }

        record = rec
        running = true
        rec.startRecording()
        thread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val filter = VoiceFilter()
            while (running) {
                val frame = ShortArray(Protocol.FRAME_SAMPLES)
                var read = 0
                while (read < Protocol.FRAME_SAMPLES && running) {
                    val n = rec.read(frame, read, Protocol.FRAME_SAMPLES - read)
                    if (n <= 0) break
                    read += n
                }
                if (!running) break
                if (read < Protocol.FRAME_SAMPLES) {
                    try { Thread.sleep(5) } catch (ignored: InterruptedException) { break }
                    continue
                }
                val out = filter.process(frame)
                if (out.isEmpty()) {
                    onFrame(null)
                } else {
                    for (f in out) onFrame(f)
                }
            }
        }, "mic").also { it.start() }
    }

    private fun close() {
        running = false
        try { thread?.join(500) } catch (ignored: InterruptedException) { }
        thread = null
        record?.let {
            try { it.stop() } catch (ignored: Exception) { }
            it.release()
        }
        record = null
        for (e in effects) {
            try { e.release() } catch (ignored: Exception) { }
        }
        effects.clear()
    }
}

/** Plays 20 ms frames through the call audio path (earbuds when connected). */
class SpeakerPlayer {
    private val jitter = JitterQueue(minStart = 3, maxStart = 15)
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    private var enhancer: LoudnessEnhancer? = null
    @Volatile private var requestedSound: List<ShortArray>? = null
    private val routeListener: () -> Unit = { applyRoute() }

    fun push(frame: ShortArray) {
        jitter.push(frame)
    }

    /** Plays the connect chime in the earphones, on top of any voices. */
    fun playChime() {
        requestedSound = Sounds.connect
    }

    /** Plays the soft power-off sound in the earphones. */
    fun playPowerOff() {
        requestedSound = Sounds.disconnect
    }

    private fun mixFrames(voice: ShortArray?, extra: ShortArray): ShortArray {
        val out = ShortArray(Protocol.FRAME_SAMPLES)
        for (k in 0 until Protocol.FRAME_SAMPLES) {
            val v = (voice?.get(k)?.toInt() ?: 0) + extra[k].toInt()
            out[k] = Protocol.softClip(v.toDouble())
        }
        return out
    }

    private fun applyRoute() {
        try { track?.setPreferredDevice(AudioRoute.output) } catch (ignored: Exception) { }
    }

    fun start() {
        val minBuf = AudioTrack.getMinBufferSize(
            Protocol.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(Protocol.SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf * 2, Protocol.FRAME_BYTES * 8))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        applyRoute()
        // Extra loudness (+6 dB) with a built-in limiter so voices are easy to hear.
        try {
            enhancer = LoudnessEnhancer(t.audioSessionId).also {
                it.setTargetGain(600)
                it.setEnabled(true)
            }
        } catch (ignored: Exception) {
        }
        AudioRoute.addListener(routeListener)
        running = true
        t.play()
        thread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val silence = ShortArray(Protocol.FRAME_SAMPLES)
            var sound: List<ShortArray>? = null
            var soundIndex = 0
            while (running) {
                val req = requestedSound
                if (req != null) {
                    requestedSound = null
                    sound = req
                    soundIndex = 0
                }
                val voice = jitter.pop()
                var frame = voice ?: silence
                val s = sound
                if (s != null) {
                    frame = mixFrames(voice, s[soundIndex])
                    soundIndex++
                    if (soundIndex >= s.size) sound = null
                }
                val n = t.write(frame, 0, Protocol.FRAME_SAMPLES)
                if (n < 0) {
                    try { Thread.sleep(20) } catch (ignored: InterruptedException) { break }
                }
            }
        }, "speaker").also { it.start() }
    }

    fun stop() {
        AudioRoute.removeListener(routeListener)
        running = false
        try { thread?.join(500) } catch (ignored: InterruptedException) { }
        thread = null
        try { enhancer?.release() } catch (ignored: Exception) { }
        enhancer = null
        track?.let {
            try { it.stop() } catch (ignored: Exception) { }
            it.release()
        }
        track = null
    }
}

/**
 * Puts call audio on the earbuds (their mic AND speaker), or on wired earphones,
 * or on the phone's loudspeaker if nothing is connected. Watches for earbuds
 * being connected or removed and switches automatically.
 */
class BluetoothRouter(context: Context) {
    private enum class Kind { BLUETOOTH, WIRED, SPEAKER }

    private val app = context.applicationContext
    private val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())
    private var started = false
    private var scoReceiver: BroadcastReceiver? = null

    private val rerouteRunnable = Runnable {
        if (started) {
            val oldIn = AudioRoute.input?.id
            val oldOut = AudioRoute.output?.id
            route()
            if (AudioRoute.input?.id != oldIn || AudioRoute.output?.id != oldOut) {
                raiseCallVolume()
                AudioRoute.changed()
            }
        }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            scheduleReroute()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            scheduleReroute()
        }
    }

    fun start(): String {
        started = true
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        if (Build.VERSION.SDK_INT < 31) registerScoReceiver()
        val label = route()
        raiseCallVolume()
        try { am.registerAudioDeviceCallback(deviceCallback, main) } catch (ignored: Exception) { }
        return label
    }

    @Suppress("DEPRECATION")
    fun stop() {
        started = false
        main.removeCallbacks(rerouteRunnable)
        try { am.unregisterAudioDeviceCallback(deviceCallback) } catch (ignored: Exception) { }
        scoReceiver?.let {
            try { app.unregisterReceiver(it) } catch (ignored: Exception) { }
        }
        scoReceiver = null
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
            } else {
                am.isBluetoothScoOn = false
                am.stopBluetoothSco()
                am.isSpeakerphoneOn = false
            }
        } catch (ignored: Exception) {
        }
        am.mode = AudioManager.MODE_NORMAL
        AudioRoute.input = null
        AudioRoute.output = null
    }

    private fun scheduleReroute() {
        if (!started) return
        main.removeCallbacks(rerouteRunnable)
        main.postDelayed(rerouteRunnable, 600)
    }

    @Suppress("DEPRECATION")
    private fun route(): String {
        val kind: Kind
        if (Build.VERSION.SDK_INT >= 31) {
            val devs = am.availableCommunicationDevices
            val bt = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                ?: devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }
            val wired = devs.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            val speaker = devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            kind = when {
                bt != null && am.setCommunicationDevice(bt) -> Kind.BLUETOOTH
                wired != null && am.setCommunicationDevice(wired) -> Kind.WIRED
                speaker != null && am.setCommunicationDevice(speaker) -> Kind.SPEAKER
                else -> Kind.SPEAKER
            }
        } else {
            kind = when {
                hasOutput(AudioDeviceInfo.TYPE_BLUETOOTH_SCO) || hasOutput(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) -> {
                    am.isSpeakerphoneOn = false
                    if (!am.isBluetoothScoOn) {
                        am.startBluetoothSco()
                        am.isBluetoothScoOn = true
                    }
                    Kind.BLUETOOTH
                }
                hasOutput(AudioDeviceInfo.TYPE_WIRED_HEADSET) || hasOutput(AudioDeviceInfo.TYPE_WIRED_HEADPHONES) ||
                    hasOutput(AudioDeviceInfo.TYPE_USB_HEADSET) -> {
                    stopLegacySco()
                    am.isSpeakerphoneOn = false
                    Kind.WIRED
                }
                else -> {
                    stopLegacySco()
                    am.isSpeakerphoneOn = true
                    Kind.SPEAKER
                }
            }
        }
        AudioRoute.input = findInput(kind)
        AudioRoute.output = findOutput(kind)
        return when (kind) {
            Kind.BLUETOOTH -> "Bluetooth earphones"
            Kind.WIRED -> "Wired earphones"
            Kind.SPEAKER -> "Phone speaker"
        }
    }

    @Suppress("DEPRECATION")
    private fun stopLegacySco() {
        if (am.isBluetoothScoOn) {
            am.isBluetoothScoOn = false
            am.stopBluetoothSco()
        }
    }

    private fun hasOutput(type: Int): Boolean =
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type == type }

    private fun findInput(kind: Kind): AudioDeviceInfo? {
        val inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val builtIn = inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
        return when (kind) {
            Kind.BLUETOOTH -> inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                ?: inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }
            Kind.WIRED -> inputs.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            } ?: builtIn
            Kind.SPEAKER -> builtIn
        }
    }

    private fun findOutput(kind: Kind): AudioDeviceInfo? {
        val outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return when (kind) {
            Kind.BLUETOOTH -> outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                ?: outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }
            Kind.WIRED -> outputs.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            Kind.SPEAKER -> outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
        }
    }

    /** Older Android: wait for the earbuds' call link, then move the mic onto it. */
    private fun registerScoReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val state = intent?.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1) ?: return
                if (state == AudioManager.SCO_AUDIO_STATE_CONNECTED && started) {
                    AudioRoute.input = findInput(Kind.BLUETOOTH)
                    AudioRoute.output = findOutput(Kind.BLUETOOTH)
                    raiseCallVolume()
                    AudioRoute.changed()
                }
            }
        }
        scoReceiver = r
        try {
            ContextCompat.registerReceiver(
                app, r, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (ignored: Exception) {
            scoReceiver = null
        }
    }

    /** Call volume starts at least at 80% so voices aren't too quiet. */
    private fun raiseCallVolume() {
        try {
            val stream = AudioManager.STREAM_VOICE_CALL
            val want = (am.getStreamMaxVolume(stream) * 0.8).roundToInt()
            if (am.getStreamVolume(stream) < want) am.setStreamVolume(stream, want, 0)
        } catch (ignored: Exception) {
        }
    }
}
